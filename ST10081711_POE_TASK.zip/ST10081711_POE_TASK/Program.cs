﻿using System;
using System.Collections.Generic;

namespace RecipeApp
{

    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }

        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
        }

        public override string ToString()
        {
            return $"{Quantity} {Unit} {Name}";
        }

        public void Scale(double factor)
        {
            Quantity *= factor;
        }

        public void ResetQuantity(double originalQuantity)
        {
            Quantity = originalQuantity;
        }
    }

    class Recipe
    {
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        public Recipe()
        {
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }

        public void AddIngredient(string name, double quantity, string unit)
        {
            Ingredients.Add(new Ingredient(name, quantity, unit));
        }

        public void AddStep(string step)
        {
            Steps.Add(step);
        }

        public void Display()
        {
            Console.WriteLine("\nIngredients:");
            foreach (Ingredient ingredient in Ingredients)
            {
                Console.WriteLine(ingredient);
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
        }

        public void Scale(double factor)
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Scale(factor);
            }
        }

        public void ResetQuantities()
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.ResetQuantity(ingredient.Quantity);
            }
        }
    }



    class Program
    {
      

        //creating expection handling 
        public static double CheckInputTypes(string input, string input1)
        {
            double j;
            bool jr = double.TryParse(input, out j);
            while (jr == false)
            {
                Console.Write("Enter the right value for: " + input1);
                input = Console.ReadLine();
                jr = double.TryParse(input, out j);

            }
            return j;
        }
        //creating expection handling for string
        public static double CheckInputTypesString(string input, string input1)
        {
            double j;
            // checking the inpu
            bool jr = double.TryParse(input, out j);
            while (jr == false)
            {
                Console.Write("Enter the right value for: " + input1);
                input = Console.ReadLine();
                jr = double.TryParse(input, out j);

            }
            return j;
        }

        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            // Get recipe details from user
            Console.Write("Enter the number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Enter the name of ingredient {i + 1}: ");
                string name = Console.ReadLine();
               

                Console.Write($"Enter the quantity of {name} (in grams, milliliters, etc.): ");
                double quantity = double.Parse(Console.ReadLine());
        

                Console.Write($"Enter the unit of measurement for {name} (e.g. grams, teaspoons, etc.): ");
                string unit = Console.ReadLine();

                recipe.AddIngredient(name, quantity, unit);
            }

            Console.Write("Enter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                string step = Console.ReadLine();

                recipe.AddStep(step);
            }

            // Display the recipe
            recipe.Display();

            // Allow user to scale the recipe by a factor
            Console.Write("\nEnter a scaling factor (0.5, 2, or 3): ");
            double factor = double.Parse(Console.ReadLine());

            recipe.Scale(factor);

            // Display the scaled recipe
            Console.WriteLine("\nScaled recipe:");
            recipe.Display();

            recipe.ResetQuantities();

            // Allow user to reset the recipe to its original quantities
            Console.Write("\nReset quantities to original values? (y/n): ");
            string reset = Console.ReadLine();

            if (reset.ToLower() == "y")
            {
                recipe.Display();
            }

            // Allow user to clear the recipe
        }
    }
}
